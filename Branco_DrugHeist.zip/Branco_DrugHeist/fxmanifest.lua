fx_version 'cerulean'
game 'gta5'

name "Branco_DrugHeist"
description "Drug hiest for qbcore"
author "Branco"
version "1.0.0"

shared_scripts {
	'shared/*.lua'
}

client_scripts {
	'client/*.lua'
}

server_scripts {
	'server/*.lua'
}
