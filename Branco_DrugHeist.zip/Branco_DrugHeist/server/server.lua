QBCore = exports["qb-core"]:GetCoreObject()

RegisterNetEvent("getitem", function()

TriggerEvent("lootcar")
Print('test virker lortet')
end)

